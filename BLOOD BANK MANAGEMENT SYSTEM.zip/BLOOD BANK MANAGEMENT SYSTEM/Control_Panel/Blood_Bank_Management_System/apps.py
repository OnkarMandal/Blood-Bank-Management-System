from django.apps import AppConfig


class BloodBankManagementSystemConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Blood_Bank_Management_System'
